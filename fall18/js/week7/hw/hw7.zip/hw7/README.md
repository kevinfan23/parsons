1. need to set up a local server with port running 8080  
2. required to Disable Cross-Origin Restrictions  
  On Safari: Developer > Disable Cross-Origin Restrictions  
  On Chrome:  
    Make sure all instance of chrome browser all closed.  
    Open terminal on mac and run the following command  
    /Applications/Google\ Chrome.app/Contents/MacOS/Google\ Chrome — disable-web-security — allow-file-access-from-files — allow-file-access  
